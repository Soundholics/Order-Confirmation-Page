package com.example.reccardapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class myadapter extends RecyclerView.Adapter<com.example.reccardapp.myviewholder>
{
   ArrayList<com.example.reccardapp.Model> data;

    public myadapter(ArrayList<com.example.reccardapp.Model> data)
    {
        this.data = data;
    }

    @NonNull
    @Override
    public com.example.reccardapp.myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.singlerow,parent,false);
        return new com.example.reccardapp.myviewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull com.example.reccardapp.myviewholder holder, int position)
    {
       holder.t1.setText(data.get(position).getHeader());
       holder.t2.setText(data.get(position).getDesc());
       holder.img.setImageResource(data.get(position).getImgname());
       Glide.with(holder.itemView.getContext()).asGif()
                .load("https://i.gifer.com/7efs.gif")
                .into(holder.tick);


    }

    @Override
    public int getItemCount()
    {
        return data.size();
    }
}
